from flask import Flask
from flask import render_template,request,session,redirect,flash
import jinja2
from mysql import connector
import time
# from dotenv import load_dotenv
# load_dotenv('\.env')
# import os
# os.environ.get('DATABASE')

app = Flask(__name__)
app.secret_key = "ujhgruighiugnfghn23urofnerh8923rfnlkwner8i"
parkingCharges = 1001
def database():
    mydb = connector.connect(host="database-1.chtrynhzzqhi.ap-south-1.rds.amazonaws.com",
                                 user="admin",
                                 password="smartparking",database="SmartParkingSystem")
    return mydb

def session_check():
    mydb = database()
    cursor = mydb.cursor(dictionary=True)
    session_phonenumber = session.get("phonenumber")
    session_password = session.get("pass")
    cursor.execute(f'''SELECT first_name,phone_number,balance,pass,last_name,tag_number
                        from user inner join rfid_info where
                        (phone_number = "{session_phonenumber}")and(pass="{session_password}");''')
    result = cursor.fetchone()
    print(result)
    return result

@app.route('/signup',methods=["GET","POST"])
def signup():

    if request.method == 'POST':
        firstName = request.form["firstname"]
        lastName = request.form["lastname"]
        phoneNumber = request.form["phonenumber"]
        password = request.form["pass"]
        balance = request.form["balance"]
        tagNumber = request.form["tagnumber"]
        city = request.form["city"]
        print(tagNumber)
        mydb = database()
        cursor = mydb.cursor()
        cursor.execute(f'''INSERT INTO user () VALUES ("{firstName}","{lastName}",{phoneNumber},"{password}",{balance},"{city}");''')
        if tagNumber:
            cursor.execute(f'''INSERT INTO rfid_info (RFID_phone_number, tag_number) VALUES ({phoneNumber},"{tagNumber}");''')
        mydb.commit()
        mydb.close()    
        session['phonenumber'] = str(phoneNumber)
        session['pass'] = str(password)
        return redirect("/")
    if request.method == "GET":
        return render_template("./signup.html")


@app.route('/signin',methods=["GET","POST"])
def signin():

    mydb = database()
    cursor = mydb.cursor(dictionary=True)

    if request.method == 'POST':
        phoneNumber = request.form["phonenumber"]
        password = request.form["pass"]

        cursor.execute(f'''SELECT first_name,phone_number,balance,pass
                from user where
                (phone_number = "{phoneNumber}")and(pass="{password}");''')

        result = cursor.fetchone()
        print(result)
        if result:
            session['phonenumber'] = str(result.get("phone_number"))
            session['pass'] = str(result.get("pass"))

            return redirect("/")

        else:
            flash("Please enter valid credentials")
            return redirect("signin")
    if request.method == "GET":
        return  render_template("./signin.html")


@app.route("/",methods=["POST","GET"])
def index():
    result = session_check()
    print(result)
    data = []
    if result:
        data.append(result.get("first_name").upper())
        data.append(result.get("balance"))
        if request.method == "GET":
            mydb = database()
            cursor = mydb.cursor()
            cursor.execute(f'''SELECT city_id, city_name FROM city;''')
            temp = cursor.fetchall()
            for item in temp:
                data.append(item)
            return render_template("./index.html", data=data)
        if request.method == "POST":
            cityId = request.form.get('selectcity')
            print("cityid", cityId)
            mydb = database()
            cursor = mydb.cursor()
            cursor.execute(f'''SELECT area_id, area_name, area_location, area_link FROM area WHERE city_area_id = {cityId};''')
            temp = cursor.fetchall()
            print(temp)
            for item in temp:
                data.append(item)
            print(data)
            return render_template("./area.html", data=data)
    else:
        return redirect("signin")


@app.route("/area",methods=["POST"])
def area():
    result = session_check()
    print(result)
    data = []
    if result:
        data.append(result.get("first_name").upper())
        data.append(result.get("balance"))
        if request.method == "POST":
            areaId = request.form.get('selectarea')
            print("areaid", areaId)
            session['area_id'] = str(areaId)
            print("wefkjbwjhbfjhwbef0", session.get('area_id'))
            return redirect("parkingslots")
    else:
        return redirect("signin")

@app.route("/parkingslots",methods=["POST","GET"])
def parkingslots():
    result = session_check()
    areaId = session.get('area_id')
    print("result", result, areaId)
    data = []
    if result:
        data.append(result.get("first_name").upper())
        data.append(result.get("balance"))
    else:
        return redirect("signin")
    booking_slot = None
    if request.method == "POST":
        booking_slot = request.form.get("name")
        mydb = database()
        cursor = mydb.cursor()
        cursor.execute(f'''select timediff(sysdate(),date_and_time), booking_cancel FROM booking_info WHERE booking_phone_number="{result['phone_number']}" order by booking_id desc limit 1;''')
        date_diff = cursor.fetchone()
        if date_diff:
            if date_diff[0].total_seconds() <= 3600 and date_diff[1]==0:
                flash("You can only book once")
                return redirect('/parkingslots')
        cursor.execute(f'''SELECT parking_id FROM SmartParkingSystem.parking WHERE area_parking_id = {areaId} and parking_number = {booking_slot};''')
        parkingId = cursor.fetchone()
        parkingId = parkingId[0]
        print("parkingId", parkingId)
        cursor.execute(f'''insert into booking_info(booking_phone_number,date_and_time,booking_parking_number,amount,booking_parking_id) values("{result['phone_number']}", sysdate(), {booking_slot}, 100, {parkingId})''')
        mydb.commit()
        print("Prking Id = ", parkingId)
        cursor.execute(f'''update parking SET slot_availability = 0 where parking_id = {parkingId};''')
        mydb.commit()
        mydb.close()
        return redirect("/parkingslots")
    mydb = database()
    cursor = mydb.cursor()
    cursor.execute(f'''SELECT slot_availability FROM area INNER JOIN parking ON (area_parking_id = area_id) WHERE area_id = {areaId};''')
    slot = cursor.fetchall()
    print("slots",slot)
    cursor.execute(f'''select timediff(sysdate(),date_and_time), booking_cancel FROM booking_info WHERE booking_phone_number="{result['phone_number']}" order by booking_id desc limit 1;''')
    date_diff = cursor.fetchone()
    for item in slot:
        data.append(item[0])
    if date_diff:
        if date_diff[0].total_seconds() <= 3600 and date_diff[1]==0:
            epocha_time = time.time() + 3600 - date_diff[0].total_seconds()
            print(round(epocha_time,0))
            data.append(True)
            data.append(epocha_time)
            cursor.execute(f'''SELECT booking_parking_number FROM booking_info WHERE booking_phone_number="{result['phone_number']}" order by booking_id desc limit 1;''')
            booking_slot = cursor.fetchone()
            if booking_slot[0]:
                data.append(booking_slot[0])
                data.append(booking_slot[0])
                cursor.execute(f'''SELECT a.area_name, c.city_name FROM booking_info b INNER JOIN parking p ON (b.booking_parking_id = p.parking_id) INNER JOIN area a ON(a.area_id = p.area_parking_id) INNER JOIN city c ON(a.city_area_id = c.city_id) where b.booking_phone_number="{result['phone_number']}" order by booking_id desc limit 1;''')
                cityDetails = cursor.fetchone()
                data.append(cityDetails[0])
                data.append(cityDetails[1])
        else:
            data.append(False)
    print(data)
    return render_template("./parkingslots.html",data=data)


@app.route("/payment",methods=["GET","POST"])
def payment():
    if request.method == "POST":
        result = session_check()
        if result:
            add_balance = request.form["balance"]
            mydb = database()
            cursor = mydb.cursor(dictionary=True)
            cursor.execute(f'''update user set balance = balance + {add_balance} where phone_number = "{result['phone_number']}";''')
            mydb.commit()
            mydb.close()
            return redirect("/")
        else:
            return redirect("signin")
    result = session_check()

    if result:
        data = []
        data.append(result.get("first_name").upper())
        data.append(result.get("last_name").upper())
        data.append(result.get("balance"))
    return render_template("./payment.html", data=data)


@app.route("/logout",methods=["POST"])
def logout():
    session["phonenumber"] = None
    session["pass"]= None
    return redirect("signin")


@app.route("/history",methods=["POST","GET"])
def history():
    result = session_check()
    if result:
        data = []
        mydb = database()
        data.append(result.get("first_name").upper())
        # data.append(result.get("last_name").upper())
        data.append(result.get("balance"))
        cursor = mydb.cursor()
        cursor.execute(
            f'''SELECT b.booking_id, convert_tz(b.date_and_time,'+00:00','+05:30'),b.booking_parking_number,b.amount FROM booking_info b where booking_phone_number="{result['phone_number']}";''')
        tempData = cursor.fetchall()
        data.append(tempData)
        print(data)
        mydb.close()
        return render_template("history.html",data=data)
    else:
        return redirect("signin")

@app.route("/cancelbooking", methods=["POST"])
def cancelbooking():
    result = session_check()
    if result:
        mydb = database()
        cursor = mydb.cursor()
        # print("result", result)
        cursor.execute(f'''UPDATE booking_info SET booking_cancel=1 WHERE booking_phone_number={result['phone_number']} ORDER BY booking_id DESC LIMIT 1;''')
        mydb.commit()
        cursor.execute(f'''SELECT booking_parking_id from booking_info WHERE booking_phone_number={result['phone_number']} ORDER BY booking_id DESC LIMIT 1;''')
        # print("parkingID ----", cursor.fetchone())
        parkingId = cursor.fetchone()
        cursor.close()
        cursor = mydb.cursor()
        print("parkingID ----", parkingId)
        cursor.execute(f'''SELECT area_parking_id from parking where parking_id = {parkingId[0]};''')
        parkingNum = cursor.fetchone()
        print("area id :", parkingNum)
        cursor.execute(f'''update parking SET slot_availability = 1 WHERE parking_number={request.form['slot']} and area_parking_id={parkingNum[0]};''')
        flash('Your Booking is Canceled')
        mydb.commit()
        cursor.execute(f'''UPDATE booking_info SET parking_done = 1 WHERE booking_phone_number ={result['phone_number']} ORDER BY booking_id DESC LIMIT 1;''')
        mydb.commit()
        cursor.execute(f'''UPDATE booking_info SET is_vehical_parked = 0 WHERE booking_phone_number ={result['phone_number']} ORDER BY booking_id DESC LIMIT 1;''')
        mydb.commit()
        mydb.close()
        return redirect('/parkingslots')
    else:
        return redirect('/signin')

@app.route("/allcars",methods=["POST","GET"])
def allcars():
    result = session_check()
    if result:
        mydb = database()
        cursor = mydb.cursor()
        cursor.execute(f'''update parking SET slot_availability = 1;''')
        mydb.commit()
        mydb.close()
        return redirect('/')
    return redirect('/')

@app.route('/checkrfid', methods = ['POST'])
def checkRFIDInfo():
    if request.method == 'POST':
        rfidNumber = str(request.form.get('rfid'))
        areaName = request.form.get('area')
        areaName = areaName.upper()
        mydb = database()
        cursor = mydb.cursor()
        cursor.execute(f'''SELECT RFID_phone_number from rfid_info where tag_number = "{rfidNumber}";''')
        phoneNumber = cursor.fetchall()
        print(phoneNumber)
        if phoneNumber == None or phoneNumber == []:
            return {"parkingNumber" : "Invalid"}
        phoneNumber = phoneNumber[0][0]
        print(phoneNumber)
        cursor.execute(f'''SELECT booking_phone_number, parking_number, booking_cancel, area_name, is_vehical_parked, booking_parking_id, parking_done from booking_info join parking on (booking_parking_id = parking_id) join area on (area_parking_id = area_id)  where booking_phone_number = {phoneNumber} order by booking_id desc limit 1;''')
        data = cursor.fetchall()
        if data == None or data == []:
            return {"parkingNumber" : "Invalid"}
        data = data[0]
        cursor.close()

        print(data, areaName)
        if data[2] == 0 and data[6] == 0:
            if data[3] == areaName:
                print("1st   if")
                if data[4] == 1:
                    return {"parkingNumber" : str(str(-data[1])+data[0])}
                cursor = mydb.cursor()
                print("update")
                cursor.execute(f'''update booking_info set is_vehical_parked = 1 where booking_phone_number = {int(phoneNumber)};''')
                mydb.commit()
                cursor.execute(f'''update booking_info set booking_cancel = 1 where booking_phone_number = {int(phoneNumber)};''')
                mydb.commit()
                mydb.close()
                return {"parkingNumber" : str(data[1])}
        elif data[2] == 1 and data[6] == 0:
            if data[3] == areaName:
                print("2nd if")
                if data[4] == 1:
                    cursor = mydb.cursor()
                    cursor.execute(f'''update parking set slot_availability = 1 where parking_id = {data[5]};''')
                    mydb.commit()
                    cursor.execute(f'''update booking_info set parking_done = 1 where booking_phone_number = {int(phoneNumber)};''')
                    mydb.commit()
                    mydb.close()
                    return {"parkingNumber" : str(str(-data[1])+data[0])}
                else:
                    return {"parkingNumber" : "Invalid"}
        print("invalid2")
        return {"parkingNumber" : "Invalid"}
        # return str(data)
        print(data)
        
@app.route('/checkbalance', methods = ['POST'])
def checkBalance():
    if request.method == 'POST':
        phoneNum = request.form.get('phone_number')
        mydb = database()
        cursor = mydb.cursor()
        cursor.execute(f'''SELECT date_and_time, user.balance from booking_info join user ON (phone_number=booking_phone_number) where booking_phone_number = {phoneNum} order by booking_id desc limit 1;''')
        data = cursor.fetchall()[0]
        print("time", data)
        time = data[0]
        balance = data[1]
        from datetime import datetime
        now = datetime.now()
        timeObject = now-time
        print('Difference: ', timeObject)
        
        minutes = timeObject.total_seconds() / 60
        charges = parkingCharges * minutes
        print('charges :', charges)
        updateValue = balance - charges
        if balance >= charges:
            cursor.execute(f'''update user set balance = {updateValue} where phone_number = {phoneNum};''')
            mydb.commit()
            cursor.execute(f'''UPDATE booking_info set amount = {charges} where booking_phone_number={phoneNum} ORDER BY booking_id DESC LIMIT 1;''')
            mydb.commit()
            mydb.close()
            return {"result" : True}
        else:
            return {"result" : False}
        # if data[2] == 0:
        #     if data[3] == areaName:
        #         if data[4] == 1:
        #             return str(-data[1]+data[0])
        #         return str(data[1])
        # return "Invalid"
        # return str(data)
        print(data)

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")

# select datediff(DATE_FORMAT(sysdate(),'%y-%m-%d'),DATE_FORMAT(date_and_time,'%y-%m-%d')) from booking_info where booking_phone_number='7218443444';