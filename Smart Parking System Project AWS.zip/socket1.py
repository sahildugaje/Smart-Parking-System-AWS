import socket
import requests
s = socket.socket()        
s.bind(('0.0.0.0', 8090 ))
s.listen(1)           

def checkRFIDInfo(id):
    url = 'http://127.0.0.1:5000/checkrfid'
    data = {'rfid':str(id[0]),
    'area':str(id[1])}
    response = requests.post(url=url,data=data)
    print(response.json()['parkingNumber'])
    return response.json()['parkingNumber']

def getTimeAndPayment(phoneNumber):
    url = 'http://127.0.0.1:5000/checkbalance'
    data = {'phone_number': str(phoneNumber)}
    response = requests.post(url=url,data=data)
    print(response.json()["result"])
    return response.json()["result"]
    
while True:
    client, addr = s.accept()
    print(client,addr)
    while True:
        content = client.recv(1024)
        if len(content) == 0:
           break
        else:
            content = content.decode('utf-8').split('?')
            parkingNum = checkRFIDInfo(content)
            if parkingNum != 'Invalid':
                if parkingNum[0] == '-':
                    phoneNumber = parkingNum[2:]
                    if getTimeAndPayment(phoneNumber):
                        parkingNum = str(parkingNum)[1]
                        sendStr = chr(97+int(parkingNum))
                        print(sendStr)
                        client.send(sendStr.encode('utf-8'))
                    else:
                        parkingNum = '-1'
                        client.send(parkingNum.encode('utf-8'))     
                else:
                    parkingNum = str(parkingNum)
                    client.send(parkingNum.encode('utf-8'))
                    
                    # client.send(b"0121")
            else:
                parkingNum = '-1'
                client.send(parkingNum.encode('utf-8'))
                

    print("Closing connection")
    client.close()
